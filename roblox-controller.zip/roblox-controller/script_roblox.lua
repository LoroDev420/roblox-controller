-- Cole este script em ServerScriptService no Roblox Studio
-- Lembre de ativar HttpService: game > HttpService > HttpEnabled = true

local HttpService = game:GetService("HttpService")

local API_URL = "https://SEU-PROJETO.onrender.com" -- ⚠️ Substitua pela sua URL do Render
local TOKEN = "meu-token-secreto-123"              -- ⚠️ Deve ser igual ao do server.js

while true do
	local ok, result = pcall(function()
		return HttpService:GetAsync(API_URL .. "/poll", false, {
			["Authorization"] = TOKEN
		})
	end)

	if ok then
		local data = HttpService:JSONDecode(result)

		for _, cmd in ipairs(data.commands) do
			local command = cmd.command
			local target = cmd.target

			-- Kickar jogador
			if command == "kick" then
				local player = game.Players:FindFirstChild(target)
				if player then
					player:Kick("Você foi kickado pelo admin.")
				end

			-- Dar dinheiro
			elseif command == "give_money" then
				local player = game.Players:FindFirstChild(target)
				if player then
					local leaderstats = player:FindFirstChild("leaderstats")
					if leaderstats and leaderstats:FindFirstChild("Cash") then
						leaderstats.Cash.Value += 1000
					end
				end

			-- Mandar mensagem para todos
			elseif command == "message" then
				local msg = Instance.new("Message")
				msg.Text = "📢 Aviso do admin!"
				msg.Parent = workspace
				wait(5)
				msg:Destroy()

			-- Mudar mapa (personalize conforme seu jogo)
			elseif command == "change_map" then
				print("Comando de troca de mapa recebido! Adicione sua lógica aqui.")
			end
		end
	else
		warn("Erro ao conectar com a API: " .. tostring(result))
	end

	wait(5) -- Verifica comandos a cada 5 segundos
end
