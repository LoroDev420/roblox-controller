const express = require('express');
const app = express();
app.use(express.json());
app.use(express.static('public'));

const SECRET_TOKEN = 'meu-token-secreto-123';
let commandQueue = [];

app.post('/command', (req, res) => {
  if (req.headers['authorization'] !== SECRET_TOKEN)
    return res.status(401).json({ error: 'Token inválido' });

  const { command, target } = req.body;
  commandQueue.push({ command, target, time: Date.now() });
  res.json({ ok: true });
});

app.get('/poll', (req, res) => {
  if (req.headers['authorization'] !== SECRET_TOKEN)
    return res.status(401).json({ error: 'Token inválido' });

  res.json({ commands: commandQueue.splice(0) });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Rodando na porta ${PORT}`));
